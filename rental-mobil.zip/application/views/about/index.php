<div class="about">
   <div class="rbx-logo" style="
      border: 2.5px solid <?= $color->value; ?>;
   "></div>
   <br>
   <h2 style="color: <?= $color->value; ?>;">Tentang kami :</h2>
   <h5>
      Berdiri sejak 1 September 2019 di Brebes Jawa tengah sebagai <strong style="color: <?= $color->value; ?>;">alternatif</strong> sekaligus 
      <br> 
      <strong style="color: <?= $color->value; ?>;">gaya baru</strong> berbisnis di bidang transportasi.
   </h5>
   <br><br>
   <h5><strong style="color: <?= $color->value; ?>;">~ RBX Mobilindo ~</strong></h5>

</div>
<div class="contact">
   <div class="rbx-logo" style="
      border: 2.5px solid <?= $color->value; ?>;
   "></div>
   <br>
   <h2 style="color: <?= $color->value; ?>;">Hubungi kami:</h2>
   <h5>
      <strong style="color: <?= $color->value; ?>;">Email: </strong> izzatalharist@gmail.com
      <br>
      <strong style="color: <?= $color->value; ?>;">Phone: </strong> 0819-0659-0037
   </h5>
</div>
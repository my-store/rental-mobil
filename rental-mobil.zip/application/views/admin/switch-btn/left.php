<div class="switch-btn-left">
   <button style="background: <?= $color->value; ?>;" class="blue-theme">Blue</button>
   <button style="background: <?= $color->value; ?>;" class="violet-theme">Violet</button>
   <button style="background: <?= $color->value; ?>;" class="green-theme">Green</button>
   <button style="background: <?= $color->value; ?>;" class="chocolate-theme">Cokelat</button>
</div>
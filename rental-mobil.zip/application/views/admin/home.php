
<div style="
   background-image: linear-gradient(176deg, <?= $color->value; ?> 70%, rgba(0, 0, 0, 0) calc(70% + 2px));
" class="banner">

<br>

<h1 style="color: white;">RBX Mobilindo</h1>

<h5>Solusi KE<strong style="color: white;">TAMPAN</strong>AN anda</h5>
<br><br>

<h5>Desa Jagapura 03/03 Kersana Brebes - Jawa tengah 52264.</h5>
<h5>Telp : (+62) 819-0659-0037</h5>

<!-- Content -->

</div>
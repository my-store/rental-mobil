<footer style="
   background: <?= $color->value; ?>;
">
<br><br><br>
   <p>Copyright &copy; Izzat alharis 2019</p>
</footer>
</body>
</html>


<!-- //=======>***)->  Izzat alharis - RBX family - Brebes - Jawa Tengah  <-(***<=======// -->


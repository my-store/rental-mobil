<!-- Nav Content -->

<nav style="background: <?= $color->value; ?>">

   <div class="burger">
      <div class="bgr1"></div>
      <div class="bgr2"></div>
      <div class="bgr3"></div>
   </div>

   <h3>RBX <span>Mobilindo</span></h3>

   <div class="top-menu">
      <button class="home-btn">Home</button>
      <button class="contact-btn">Contact</buttona>
         <button class="about-btn">About</button>
   </div>

</nav>